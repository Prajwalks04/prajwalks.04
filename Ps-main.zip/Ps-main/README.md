<h1 align="left"><img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="25px"> Hi, I'm Vishu Pented</h1>

## You Know Me?

<p align="left"> <a href="https://github.com/VishuPented/VishuPented"><img src="https://komarev.com/ghpvc/?username=VishuPented&label=Profile%20views&color=0e75b6&style=flat" alt="vishupented" /></a> </p>

<details>
  <summary>GitHub Stats</summary>
  <br/>
<p align="left"> <a href="https://github.com/VishuPented/VishuPented"><img src="https://github-profile-trophy.vercel.app/?username=vishupented" alt="vishupented" /></a> </p>

</details>

<p>&nbsp;<img align="center" src="https://github-readme-stats.vercel.app/api?username=vishupented&show_icons=true&locale=en" alt="vishupented" /></p>

<details>
    <summary>Top Languages</summary>
    <br/>

[![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=vishupented)](https://github.com/vishupented)
</details>

<details>
    <summary>Languages</summary>
    <br/>
<p align="left"> <a href="https://www.gnu.org/software/bash/" target="_blank"> <img src="https://www.vectorlogo.zone/logos/gnu_bash/gnu_bash-icon.svg" alt="bash" width="40" height="40"/> </a> <a href="https://git-scm.com/" target="_blank"> <img src="https://github.com/Thomas-George-T/Thomas-George-T/raw/master/assets/git.svg" alt="git" width="40" height="40"/> </a> <a href="https://www.w3.org/html/" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original-wordmark.svg" alt="html5" width="40" height="40"/> </a> <a href="https://www.python.org" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> </a> </p>

</details>

### Follow on:
[![VishuPented](https://img.icons8.com/fluent/48/000000/twitter.png)][twitter]
[![VishuPented](https://img.icons8.com/fluent/48/000000/instagram-new.png)][instagram]
[![VishuPented](https://img.icons8.com/fluent/48/000000/linkedin.png)][Linkedin]



[twitter]: https://twitter.com/vishupented04
[instagram]: https://instagram.com/vishupented.04
[linkedin]: https://www.linkedin.com/in/vishwanath-pented-044b6b252/

